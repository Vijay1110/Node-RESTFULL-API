const mongoose = require("mongoose");
const Joi = require("joi");

const Customer = mongoose.model(
  "Customer",
  new mongoose.Schema({
    isGold: {
      required: true,
      type: Boolean
    },
    name: {
      required: true,
      type: String,
      minlength: 4,
      maxlength: 20
    },
    phone: {
      required: true,
      type: String,
      minlength: 10,
      maxlength: 20
    }
  })
);

function validateCustomer(customer) {
  const schema = {
    name: Joi.string()
      .min(4)
      .max(20)
      .required(),
    phone: Joi.string()
      .min(10)
      .max(20)
      .required(),
    isGold: Joi.boolean()
  };

  return Joi.validate(customer, schema);
}

exports.Customer = Customer;
exports.validate = validateCustomer;
