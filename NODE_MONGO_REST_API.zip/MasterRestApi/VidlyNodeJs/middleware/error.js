const winston = require("winston");

module.exports = function(err, req, res, next) {
  // winston.log("error", err.message);
  winston.error(err.message, err);
  //Login Level
  //error
  //warn
  //info => we are storing information in the log like connected to mongodb
  //verbose
  //debug
  //silly

  res.status(500).send("Something failed");
};
